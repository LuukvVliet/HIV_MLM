Libraries
===========
Here should be placed Symlinks to used libraries

###Boost
Download, build [boost 1 54][1] than create a Symlink:

    mklink /D Boost Your:\Path\To\Boost


  [1]: http://www.boost.org/